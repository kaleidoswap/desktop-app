# Changelog

## [0.5.0] - 2026-10-09

- Keep independent HTTP sessions alive across requests; bound idle session retention and return request errors without crashing the server.
- Default HTTP to loopback; require authentication for remote binding. Docker uses Node 22 and requires MCP_AUTH_TOKEN.
- Reserve submarine funding attempts before broadcast, atomically persist records, and report ambiguous funding outcomes for manual reconciliation. Concurrent creates reserve distinct refund-key indices.

### Migration

- HTTP binds to `127.0.0.1` by default. Remote/container deployments must explicitly set `MCP_HOST` and `MCP_AUTH_TOKEN`; clients send `Authorization: Bearer <token>`.
- Initialize an MCP session and reuse its `Mcp-Session-Id`. Idle sessions expire after 30 minutes; clients must initialize again after expiry.
- Persist the swap storage directory across restarts. An ambiguous funding result requires manual chain/wallet reconciliation; do not delete reservation markers or automatically retry a broadcast.
- No live funded swap was executed for this release. Automated checks cover session handling, reservations and mocked funding failures.

All notable changes to this project are documented here. The format follows
[Keep a Changelog](https://keepachangelog.com/en/1.1.0/) and the project uses
[Semantic Versioning](https://semver.org/) (pre-1.0: minor bumps may break).

## [0.4.5] - 2026-10-08

### Fixed

- `kaleidoswap_get_quote` returns, and quotes the maker with, the asset's RGB id when given a ticker (`to_asset_id:
  "USDT"` now yields `to_asset.asset_id: "rgb:..."`), so the id matches what `rln_list_channels` reports and callers
  that match quote legs to channels no longer see a ticker. `kaleidoswap_atomic_init` resolves a ticker the same
  way, so a quote and its init always carry the same ids (the maker rejects an init whose ids differ from the quote).

### Changed

- `kaleidoswap_lsp_estimate_fees` and `kaleidoswap_lsp_create_order` say that one payment is capped at about 10% of
  the channel capacity, so a BTC→asset swap of X sat needs a channel of at least 10 × (X + 3,000 sat).

## [0.4.4] - 2026-10-08

### Fixed

- `kaleidoswap_get_quote` checks the amount against the pair's per-layer limits from `/market/pairs` (cached for 60
  s) before calling the maker, and reports the limits in display units of the asset, e.g. "USDT amount must be
  between 0.5 USDT and 1,000 USDT (you asked to receive 2,500 USDT)". When a sat count looks misplaced the error says
  how to express it: "set from_asset_id BTC and from_amount in BTC (2,500 sats = 0.000025)". Maker range errors in
  raw units ("to_amount must be between 500000 and 1000000000") are rewritten the same way.
- `kaleidoswap_atomic_init` rewrites maker range errors in display units of the leg they name.

### Added

- `kaleidoswap_get_quote` accepts `from_amount_sat` / `to_amount_sat` for a BTC leg as an alternative to
  `from_amount` / `to_amount` in BTC.

### Changed

- The `kaleidoswap_get_quote` description states that amounts are display units (BTC, not sats) and gives the
  example "sell 2,500 sats → from_asset_id BTC, from_amount 0.000025".

## [0.4.3] - 2026-10-08

### Fixed

- `kaleidoswap_atomic_init` checks the node's channels before contacting the maker. A swap the channels cannot
  carry used to be quoted, created, whitelisted and executed, then fail on the maker with `NoRoute`. It now returns an
  error with the shortfall, e.g. "Need 2,500 more sat outbound (have 3,000, swap 2,500 + 3,000 sat RGB HTLC
  minimum)", and nothing is created. The rule follows RLN's swap routes:
  - BTC→asset: some usable channel with `next_outbound_htlc_limit_msat` >= swap amount + `rgb_htlc_min_msat`, and an
    asset channel with inbound asset >= the amount bought and at least `rgb_htlc_min_msat` of BTC inbound.
  - asset→BTC: an asset channel with outbound asset >= the amount sold and at least `rgb_htlc_min_msat` of BTC
    outbound, and BTC inbound >= the amount bought + `rgb_htlc_min_msat`.

  `wdk_atomic_taker` and `kaleidoswap_atomic_execute` run the same check on the swapstring. When the channels or
  assets cannot be read the swap goes ahead with a `preflight_warning`.
- Tool descriptions and hints named the legacy `rln_*` tools; they now name the `wdk_*` tools. The `rln_*` aliases
  remain.

### Changed

- `kaleidoswap_lsp_estimate_fees` and `kaleidoswap_lsp_create_order` explain that `client_balance_sat` is your
  outbound for swaps, and that a BTC→asset swap of X sat needs `client_balance_sat` >= X + 3,000 sat plus the channel
  reserve.

## [0.4.2] - 2026-10-07

### Fixed

- `kaleidoswap_lsp_get_order` takes a required `access_token` and sends it to the maker. Without it every poll
  failed with "Invalid order access token".
- `kaleidoswap_lsp_create_order` returned a flat `onchain_amount_sat` that held only the fee, so paying it underpaid
  the order. The amount to pay is now `amount_due_sat` (the maker's `order_total_sat`: fee + `client_balance_sat`
  + `asset_price_sat`), with the fee alone in `fee_sat`.
- `kaleidoswap_lsp_quote_asset_channel` returned `btc_amount_sat` in msat; it is now in sats. `channel_fee_sat` was
  always null because the tool read a field the maker does not return; it is now the estimate's `total_fee`, priced
  with the same `client_asset_amount` the order sends, so `total_sat` matches the order's `amount_due_sat`. The
  estimate no longer needs the node pubkey. A failed estimate leaves `total_sat` null and sets `fee_error`.

### Changed

- **Breaking result shape** for `kaleidoswap_lsp_create_order`, `kaleidoswap_lsp_get_order` and
  `kaleidoswap_lsp_create_asset_channel`. They return one normalised order: `order_id`, `order_state`,
  `access_token`, `amount_due_sat`, `fee_sat`, the accepted balances and asset amounts, `channel`, `failure_reason`,
  and `payment: { bolt11: { invoice, amount_sat, state, expires_at }, onchain: { address, amount_sat, state,
  expires_at, ... } }`. Removed: the flat `bolt11_invoice`, `onchain_address`, `onchain_amount_sat`,
  `order_total_sat`, `fee_total_sat` and the raw order spread; `create_asset_channel`'s `total_sat` is now
  `amount_due_sat`.
- `kaleidoswap_lsp_create_order` accepts `refund_onchain_address`; `kaleidoswap_lsp_estimate_fees` accepts
  `client_asset_amount`, which the maker needs to price an asset purchase. `kaleidoswap_lsp_quote_asset_channel`
  adds `fee_breakdown` (setup, capacity, duration, and `other_fee_sat` for the asset fee the API does not itemise); `kaleidoswap_lsp_get_info` lists each asset's `precision`. LSP tool descriptions state units
  (sats, raw asset units).

## [0.4.1] - 2026-10-07

### Changed

- `wdk_send_asset` / `rln_send_asset` and `wdk_create_rgb_invoice` / `rln_create_rgb_invoice` accept a ticker
  (e.g. `USDT`, case-insensitive) in `asset_id`, resolved against the node's assets; a CFA asset, which has no
  ticker, matches by name. A value starting with `rgb:` is used as the asset ID. No match, or more than one, returns
  an error listing the candidates. The invoice result now echoes the resolved `asset_id`.

## [0.4.0] - 2026-10-07

### Added

- Submarine swaps on the Boltz `/v2` maker (kaleidoswap-maker-rs): pay a Lightning invoice from L-USDT or L-BTC on
  Liquid. `kaleidoswap_submarine_pairs`, `kaleidoswap_submarine_create`, `kaleidoswap_submarine_fund` (spend; takes only
  the swap id) and `kaleidoswap_submarine_status`, through the optional peer `@kaleidorg/swap-sdk` (Node ≥ 22). Refund
  keys derive from the wallet mnemonic; swap records are persisted in `KALEIDOSWAP_SWAP_DIR` before funding. New
  settings: `KALEIDOSWAP_MAKER_URL`, `KALEIDOSWAP_SWAP_DIR`.

### Fixed

- `wdk_issue_asset` / `rln_issue_asset` no longer echo a `ticker` for CFA assets, which have none.
- `wdk_list_transfers` / `rln_list_transfers`: `amount_raw` was taken from the first assignment, which
  for a send can be our own change. It is now the requested amount, or the sum received/issued, and
  `null` for sends. A new `assignments_raw` field lists every assignment value.

## [0.3.1] - 2026-10-06

### Changed

- `KALEIDO_NETWORK` now defaults to `signet`, the only network with a public KaleidoSwap API.
  `npx -y kaleido-mcp` with no configuration talks to `https://api.signet.kaleidoswap.com`.
- `KALEIDO_NETWORK=mainnet` no longer has a default KaleidoSwap API URL: set `KALEIDOSWAP_API_URL`
  (or `KALEIDO_API_URL`) or the server exits at startup with an error naming the variable. Spark and
  Liquid mainnet presets are unchanged.
- `@tetherto/wdk-wallet-spark` and `@kaleidorg/wdk-wallet-liquid` are now optional peer dependencies
  and are no longer installed with kaleido-mcp. A clean install drops from about 620 MB / 337 packages
  to about 290 MB / 257 packages; most of the remainder is the WDK MCP toolkit's runtime. To use the Spark or Liquid tools, install the package next to
  kaleido-mcp, e.g. `npx -y -p kaleido-mcp -p @tetherto/wdk-wallet-spark kaleido-mcp`. When a seed is
  set but the package is missing, the server starts without those tools and logs which package to
  install. The Docker image still ships both.
- Dropped the unused direct dependency on `@tetherto/wdk`.
- The Docker image no longer sets `KALEIDOSWAP_API_URL`; it follows `KALEIDO_NETWORK` like the npm package.

## [0.3.0] - 2026-10-06

### Breaking

- Removed the order-based swap tools: `kaleidoswap_place_order`,
  `kaleidoswap_get_order_status`, `kaleidoswap_get_open_orders`,
  `kaleidoswap_cancel_order` and `kaleidoswap_get_position`. The REST swap-order
  surface is gone from `kaleido-sdk`; use the atomic HTLC flow
  (`kaleidoswap_get_quote` → `kaleidoswap_atomic_init` → `wdk_atomic_taker` →
  `kaleidoswap_atomic_execute` → `kaleidoswap_atomic_status`).

### Added

- Consolidated the standalone wallet MCP servers into kaleido-mcp, which now supersedes
  `wdk-wallet-mcp` (RLN), `wdk-wallet-spark-mcp` and `wdk-wallet-liquid-mcp`; tool names are unchanged.
- RGB issuance tools `wdk_issue_asset` (NIA, CFA or UDA; the display amount is scaled by
  `precision`, invalid arguments return an `isError` result), `wdk_create_utxos` and
  `wdk_list_transfers`, each with an `rln_*` alias.
- Liquid wallet tools (`liquid_get_node_info`, `liquid_get_address`, `liquid_get_balance`,
  `liquid_get_asset_balance`, `liquid_list_assets`, `liquid_list_transactions`,
  `liquid_list_unspents`, `liquid_send_btc`, `liquid_send_asset`, `liquid_get_fee_rates`) backed
  by an in-process LWK wallet (`@kaleidorg/wdk-wallet-liquid`, adds about 10 MB of WebAssembly to
  the install). Enabled by `LIQUID_MNEMONIC` or, failing that, `WDK_SEED`; the modules are only
  loaded when one is set. `LIQUID_NETWORK` follows `KALEIDO_NETWORK` (`mainnet`, or `testnet` on
  signet) and `LIQUID_ESPLORA_URL` overrides the Esplora endpoint.
- `KALEIDO_NETWORK` preset (`mainnet` default, or `signet`). `signet` points the
  KaleidoSwap tools at `https://api.signet.kaleidoswap.com` and Spark at
  `REGTEST`. Explicit `KALEIDOSWAP_API_URL` / `SPARK_NETWORK` still win, and the
  active network is logged to stderr at startup. Unknown values exit with an error.
- `RGB_PROXY_ENDPOINT`, defaulting per network (signet: `rpcs://proxy.iriswallet.com/0.2/json-rpc`,
  the same proxy the `kaleido` CLI uses; mainnet: none).
- `KALEIDO_API_URL` is accepted as an alias for `KALEIDOSWAP_API_URL`.
- `kaleido_node_*` lifecycle tools (`list`, `up`, `stop`, `down`, `ps`,
  `status`, `info`, `use`, `init`, `unlock`, `lock`) that drive a local RGB
  Lightning Node through the `kaleido` CLI.
- Spark invoice tools: `spark_create_sats_invoice` and `spark_create_tokens_invoice` accept
  `sender_spark_address` and `expiry_minutes`; `spark_pay_invoice` and `spark_get_invoices` are the
  canonical names (`spark_pay_spark_invoice` / `spark_get_spark_invoices` remain as aliases), and
  `spark_pay_invoice` takes a per-invoice `amount` string (sats or token base units).
- `docs/TOOLS.md`, generated from the live tool registry by `npm run docs:tools`.
- CI workflow running build and contract tests on pull requests and `main`.
- `CHANGELOG.md` is shipped in the npm package.

### Fixed

- `wdk_create_rgb_invoice` sent an empty `transport_endpoints` list, producing invoices the payer
  could not deliver a consignment for. It and `wdk_send_asset` now fall back to `RGB_PROXY_ENDPOINT`
  when no endpoints are passed; explicit `transport_endpoints` still win.
- `spark_get_invoices` passed a bare array to the Spark SDK, which expects `{ invoices }`; Spark
  invoice results containing bigints no longer fail to serialise.
- `wdk_create_rgb_invoice` no longer returns a `usage` hint pointing at the removed order flow.

### Changed

- `kaleido-sdk` bumped to 0.1.18 (RGB Lightning Node 0.9.0 API).
- The Spark/WDK wallet modules are only loaded when `WDK_SEED` is set; seedless
  startup is roughly 45% faster.
- Empty environment variables are treated as unset, so the defaults apply.
- The MCP server now reports the package version instead of a hardcoded `1.0.0`.
- `@tetherto/wdk-mcp-toolkit` is pinned to a commit (no usable npm release yet).
- Contract tests are self-contained and no longer depend on files outside the repo.
- Tool descriptions no longer reference the removed order flow.
- README rewritten around `npx -y kaleido-mcp` with signet quickstart.
