import { describe, expect, it } from 'vitest';
import { ToolRegistry } from '../tools/registry.js';
import { InProcessToolSource } from '../tools/in-process.js';
import type { LLMProvider } from '../providers/types.js';
import { runRecipe } from './runner.js';
import { kaleidoswapAtomicRecipe } from './kaleidoswap-atomic.js';

// LLM provider that should never be called when slots are pre-supplied to runRecipe
// (or when a recipe is not using forceModelExtract).
const refusingProvider: LLMProvider = {
  name: 'refusing',
  runTurn: async () => {
    throw new Error('provider should NOT be called (slots pre-supplied or det path)');
  },
};

/**
 * Stub the maker + node tools. The quote echoes full asset specs (asset_id +
 * maker-unit amount) the way the real maker does, so init can source them.
 */
function buildStubs(captured: { name: string; args: any }[]) {
  const tool = (name: string, response: any, spend = false) => ({
    name,
    description: '',
    parameters: { type: 'object', properties: {} },
    requiresConfirmation: spend,
    handler: async (a: any) => {
      captured.push({ name, args: a });
      return typeof response === 'function' ? response(a) : response;
    },
  });
  return new ToolRegistry([
    new InProcessToolSource('kaleidoswap', [
      // Mirror the REAL kaleido-mcp `kaleidoswap_get_quote` response: each leg
      // echoes asset_id + ticker + layer + amount_raw (integer) + amount_display.
      tool('kaleidoswap_get_quote', {
        rfq_id: 'rfq-1',
        from_asset: { asset_id: 'USDT', ticker: 'USDT', layer: 'RGB_LN', amount_raw: 10_000_000, amount_display: '10' },
        to_asset: { asset_id: 'BTC', ticker: 'BTC', layer: 'BTC_LN', amount_raw: 15_250_000, amount_display: '15,250 sats' },
        fee_display: '154 sats',
      }),
      tool('kaleidoswap_atomic_init', { swapstring: 'SWAP/abc/def', payment_hash: 'ph-1' }, /* spend */ true),
      tool('kaleidoswap_atomic_execute', { status: 200, message: 'Swap executed successfully.' }, /* spend */ true),
    ]),
    new InProcessToolSource('rln', [
      tool('rln_get_node_info', { pubkey: '03c31dae' }),
      tool('rln_atomic_taker', { ok: true }, /* spend */ true),
    ]),
  ]);
}

describe('kaleidoswapAtomicRecipe — selection', () => {
  it('triggers on swap phrasings', () => {
    expect(kaleidoswapAtomicRecipe.match!('swap 10 usdt to btc')).toBe(true);
    expect(kaleidoswapAtomicRecipe.match!('exchange 100000 sats for usdt')).toBe(true);
    expect(kaleidoswapAtomicRecipe.match!('convert btc to usdt')).toBe(true);
  });
  it('triggers on buy/sell of a crypto asset (the reported bug)', () => {
    expect(kaleidoswapAtomicRecipe.match!('buy one usdt from kaleido')).toBe(true);
    expect(kaleidoswapAtomicRecipe.match!('sell 100 usdt')).toBe(true);
  });
  it('does NOT trigger on buying a gift card (that is commerce, not a swap)', () => {
    expect(kaleidoswapAtomicRecipe.match!('buy a gift card')).toBe(false);
    expect(kaleidoswapAtomicRecipe.match!('buy an amazon voucher')).toBe(false);
  });
  it('does not trigger on a balance question', () => {
    expect(kaleidoswapAtomicRecipe.match!('what is my balance')).toBe(false);
  });
  it('DEFERS to Flashnet when a Flashnet/Spark cue is present (venue split)', () => {
    // These belong to the agentic flashnet-swaps skill, not the KaleidoSwap
    // maker recipe — so the recipe must NOT claim them.
    expect(kaleidoswapAtomicRecipe.match!('swap 10000 sats with asset of your choice in flashnet')).toBe(false);
    expect(kaleidoswapAtomicRecipe.match!('swap 5000 sats to usdb')).toBe(false);
    expect(kaleidoswapAtomicRecipe.match!('swap btc to usdb on spark')).toBe(false);
  });
  it('does NOT claim a bare swap with no venue/asset cue (falls to agentic)', () => {
    // Ambiguous — a swap always needs a target asset; let the skill tier ask
    // or pick the connected venue rather than grabbing it for the maker.
    expect(kaleidoswapAtomicRecipe.match!('swap 100000 sats')).toBe(false);
    expect(kaleidoswapAtomicRecipe.match!('exchange some bitcoin')).toBe(false);
  });
  it('still claims swaps that name an RGB/maker asset', () => {
    expect(kaleidoswapAtomicRecipe.match!('swap 100000 sats to usdt')).toBe(true);
    expect(kaleidoswapAtomicRecipe.match!('convert btc to xaut')).toBe(true);
  });
  it('does not turn portfolio review or explicit no-trade language into a swap', () => {
    expect(kaleidoswapAtomicRecipe.match!('review my portfolio allocation but do not trade')).toBe(false);
    expect(kaleidoswapAtomicRecipe.match!('analyze my holdings without trading')).toBe(false);
  });
});

describe('kaleidoswapAtomicRecipe — forceModelExtract (less deterministic slot parsing)', () => {
  it('always uses 1 LLM inference for slots even when a det extract would succeed (model does the NL understanding)', async () => {
    const captured: { name: string; args: any }[] = [];
    const tools = buildStubs(captured);

    // Provider that handles the synthetic extract_request tool the runner builds.
    const modelExtractProvider: LLMProvider = {
      name: 'model-extract',
      runTurn: async (input) => {
        // The runner sends a single-turn request with the extract tool.
        const call = input.tools?.find((t) => t.name === 'extract_request');
        if (call && input.messages.some((m) => m.role === 'user' && /usdt/i.test(m.content || ''))) {
          // Simulate the model correctly parsing a natural "buy" phrasing.
          return {
            text: '',
            rawContent: '',
            toolCalls: [{
              id: 'ex1',
              name: 'extract_request',
              arguments: { from_asset: 'BTC', to_asset: 'USDT', amount: 1, amount_side: 'to' },
            }],
          };
        }
        return { text: '', rawContent: '', toolCalls: [] };
      },
    };

    const res = await runRecipe(kaleidoswapAtomicRecipe, 'buy 1 usdt', {
      provider: modelExtractProvider,
      tools,
      onConfirm: async () => ({ approved: true }),
    });

    expect(res.status).toBe('done');
    expect(res.inferences).toBe(1); // forced through the model
    // The execution still used the model-provided slots (from_asset came from the "model" not regex default).
    // (The stub quote in the test is for USDT→BTC, but the point is the inference count + that it ran.)
    expect(captured[0].name).toBe('kaleidoswap_get_quote');
  });

  it('degrades to the deterministic extractor when the forced inference is cancelled', async () => {
    // On small on-device models the forced extraction inference can ramble and
    // be cancelled/time out. That must NOT fail a request the regex understood:
    // "buy 1 usdt" should still run the full chain off the deterministic slots.
    const captured: { name: string; args: any }[] = [];
    const tools = buildStubs(captured);
    const cancellingProvider: LLMProvider = {
      name: 'cancelling',
      runTurn: async () => {
        throw new Error('Inference request "abc" was cancelled before it could complete');
      },
    };

    const res = await runRecipe(kaleidoswapAtomicRecipe, 'buy 1 usdt', {
      provider: cancellingProvider,
      tools,
      onConfirm: async () => ({ approved: true }),
    });

    expect(res.status).toBe('done');
    expect(res.inferences).toBe(0); // model never produced — fell back to regex
    // Buy-side: amount on the receive leg, layers derived.
    expect(captured.find((c) => c.name === 'kaleidoswap_get_quote')!.args).toEqual({
      from_asset_id: 'BTC', to_asset_id: 'USDT',
      from_layer: 'BTC_LN', to_layer: 'RGB_LN', to_amount: 1,
    });
  });

  it('stops the chain (status cancelled) when the abort signal fires during extraction', async () => {
    // The stop button aborts the signal mid-inference. extractSlots must NOT
    // paper over an explicit cancel with deterministic slots — the recipe must
    // report cancelled and run NO steps (nothing sent).
    const captured: { name: string; args: any }[] = [];
    const tools = buildStubs(captured);
    const ctrl = new AbortController();
    const abortingProvider: LLMProvider = {
      name: 'aborting',
      runTurn: async () => {
        ctrl.abort(); // simulate the user pressing stop while the model runs
        throw new Error('Inference request "x" was cancelled before it could complete');
      },
    };

    const res = await runRecipe(kaleidoswapAtomicRecipe, 'buy 1 usdt', {
      provider: abortingProvider,
      tools,
      onConfirm: async () => ({ approved: true }),
      signal: ctrl.signal,
    });

    expect(res.status).toBe('cancelled');
    expect(res.text).toBe('Stopped.');
    expect(captured).toHaveLength(0); // nothing ran — not even the read-only quote
  });
});

describe('kaleidoswapAtomicRecipe — full chain', () => {
  it('runs quote → init → nodeinfo → whitelist → execute in order (one inference)', async () => {
    const captured: { name: string; args: any }[] = [];
    const tools = buildStubs(captured);

    const res = await runRecipe(kaleidoswapAtomicRecipe, 'swap 10 usdt to btc', {
      provider: refusingProvider,
      tools,
      onConfirm: async () => ({ approved: true }),
      // Pre-supply slots so refusingProvider is not hit. This simulates a
      // successful prior extraction (the normal fast path for most recipes,
      // or the early Funnel heuristic for forceModelExtract recipes).
      slots: { from_asset: 'USDT', to_asset: 'BTC', amount: 10, amount_side: 'from' },
    });

    expect(res.status).toBe('done');
    expect(res.inferences).toBe(0);
    expect(captured.map((c) => c.name)).toEqual([
      'kaleidoswap_get_quote',
      'rln_get_node_info',
      'kaleidoswap_atomic_init',
      'rln_atomic_taker',
      'kaleidoswap_atomic_execute',
    ]);
  });

  it('threads quote → init args (flat asset ids + maker-unit amounts)', async () => {
    const captured: { name: string; args: any }[] = [];
    const tools = buildStubs(captured);
    await runRecipe(kaleidoswapAtomicRecipe, 'swap 10 usdt to btc', {
      provider: refusingProvider, tools, onConfirm: async () => ({ approved: true }),
      slots: { from_asset: 'USDT', to_asset: 'BTC', amount: 10, amount_side: 'from' },
    });
    const init = captured.find((c) => c.name === 'kaleidoswap_atomic_init')!;
    expect(init.args).toEqual({
      rfq_id: 'rfq-1',
      from_asset_id: 'USDT', from_amount_raw: 10_000_000,
      to_asset_id: 'BTC', to_amount_raw: 15_250_000,
    });
  });

  it('builds get_quote args matching the kaleido-mcp schema (sell vs buy leg)', async () => {
    // The reported bug: the recipe must emit the MCP tool's field names
    // (from_asset_id/to_asset_id/from_layer/to_layer) and put the amount on the
    // correct leg — to_amount for "buy 1 usdt", from_amount for a sell/swap.
    const sell: { name: string; args: any }[] = [];
    await runRecipe(kaleidoswapAtomicRecipe, 'swap 10 usdt to btc', {
      provider: refusingProvider, tools: buildStubs(sell), onConfirm: async () => ({ approved: true }),
      slots: { from_asset: 'USDT', to_asset: 'BTC', amount: 10, amount_side: 'from' },
    });
    expect(sell.find((c) => c.name === 'kaleidoswap_get_quote')!.args).toEqual({
      from_asset_id: 'USDT', to_asset_id: 'BTC',
      from_layer: 'RGB_LN', to_layer: 'BTC_LN', from_amount: 10,
    });

    const buy: { name: string; args: any }[] = [];
    await runRecipe(kaleidoswapAtomicRecipe, 'buy 1 usdt', {
      provider: refusingProvider, tools: buildStubs(buy), onConfirm: async () => ({ approved: true }),
      slots: { from_asset: 'BTC', to_asset: 'USDT', amount: 1, amount_side: 'to' },
    });
    expect(buy.find((c) => c.name === 'kaleidoswap_get_quote')!.args).toEqual({
      from_asset_id: 'BTC', to_asset_id: 'USDT',
      from_layer: 'BTC_LN', to_layer: 'RGB_LN', to_amount: 1,
    });
  });

  it('threads init.swapstring + node.pubkey + init.payment_hash → execute', async () => {
    const captured: { name: string; args: any }[] = [];
    const tools = buildStubs(captured);
    await runRecipe(kaleidoswapAtomicRecipe, 'swap 10 usdt to btc', {
      provider: refusingProvider, tools, onConfirm: async () => ({ approved: true }),
      slots: { from_asset: 'USDT', to_asset: 'BTC', amount: 10, amount_side: 'from' },
    });
    const whitelist = captured.find((c) => c.name === 'rln_atomic_taker')!;
    expect(whitelist.args).toEqual({ swapstring: 'SWAP/abc/def' });
    const exe = captured.find((c) => c.name === 'kaleidoswap_atomic_execute')!;
    expect(exe.args).toEqual({
      swapstring: 'SWAP/abc/def',
      taker_pubkey: '03c31dae',
      payment_hash: 'ph-1',
    });
  });
});

describe('kaleidoswapAtomicRecipe — single confirmation', () => {
  it('fires ONE gate (before init), showing the quote summary, then runs ungated', async () => {
    const captured: { name: string; args: any }[] = [];
    const tools = buildStubs(captured);
    const confirms: { name: string; summary?: string }[] = [];

    const res = await runRecipe(kaleidoswapAtomicRecipe, 'swap 10 usdt to btc', {
      provider: refusingProvider,
      tools,
      onConfirm: async (call) => {
        confirms.push({ name: call.name, summary: (call as any).summary });
        return { approved: true };
      },
      slots: { from_asset: 'USDT', to_asset: 'BTC', amount: 10, amount_side: 'from' },
    });

    expect(res.status).toBe('done');
    // Exactly one confirm, on the first spend step (init), with the rich summary.
    expect(confirms).toHaveLength(1);
    expect(confirms[0]!.name).toBe('kaleidoswap_atomic_init');
    expect(confirms[0]!.summary).toContain('10 USDT');
    expect(confirms[0]!.summary).toContain('15,250 sats');
    expect(confirms[0]!.summary).toContain('154 sats');
  });

  it('declining the single gate cancels the whole chain before any spend', async () => {
    const captured: { name: string; args: any }[] = [];
    const tools = buildStubs(captured);

    const res = await runRecipe(kaleidoswapAtomicRecipe, 'swap 10 usdt to btc', {
      provider: refusingProvider,
      tools,
      onConfirm: async () => ({ approved: false, reason: 'user said no' }),
      slots: { from_asset: 'USDT', to_asset: 'BTC', amount: 10, amount_side: 'from' },
    });

    expect(res.status).toBe('cancelled');
    // Quote ran (read-only), but NOTHING after the declined gate.
    expect(captured.map((c) => c.name)).toEqual(['kaleidoswap_get_quote', 'rln_get_node_info']);
  });
});

describe('kaleidoswapAtomicRecipe — channel liquidity preflight', () => {
  const btcToUsdt = {
    rfq_id: 'rfq-2',
    from_asset: { asset_id: 'BTC', ticker: 'BTC', layer: 'BTC_LN', amount_raw: 50_000_000, amount_display: '50,000 sats' },
    to_asset: { asset_id: 'rgb:usdt', ticker: 'USDT', layer: 'RGB_LN', amount_raw: 30_000_000, amount_display: '30' },
  };
  const usdtToBtc = {
    rfq_id: 'rfq-3',
    from_asset: { asset_id: 'rgb:usdt', ticker: 'USDT', layer: 'RGB_LN', amount_raw: 10_000_000, amount_display: '10' },
    to_asset: { asset_id: 'BTC', ticker: 'BTC', layer: 'BTC_LN', amount_raw: 15_000_000, amount_display: '15,000 sats' },
  };
  const usdtChannel = (over: Record<string, unknown> = {}) => ({
    ready: true,
    is_usable: true,
    asset_id: 'rgb:usdt',
    asset_local_amount: 20_000_000,
    asset_remote_amount: 40_000_000,
    next_outbound_htlc_limit_msat: 60_000_000,
    inbound_balance_msat: 50_000_000,
    ...over,
  });

  it('BTC -> asset: BTC outbound must cover the amount plus the HTLC minimum', async () => {
    const { swapLiquidityShortfall } = await import('./kaleidoswap-atomic.js');
    expect(swapLiquidityShortfall(btcToUsdt as never, { channels: [usdtChannel({ next_outbound_htlc_limit_msat: 51_000_000 })] })).toBe(
      'your channels can send at most 51,000 sats, and this swap needs 53,000 sats (the amount plus the 3,000 sats HTLC minimum). Swap at most 48,000 sats, or buy a bigger channel.',
    );
    expect(swapLiquidityShortfall(btcToUsdt as never, { channels: [usdtChannel()] })).toBeNull();
    expect(swapLiquidityShortfall(btcToUsdt as never, { channels: [usdtChannel({ next_outbound_htlc_limit_msat: 3_000_000 })] })).toBe(
      'your channels can send at most 3,000 sats, which only covers the 3,000 sats HTLC minimum, so no BTC swap fits. This one needs 53,000 sats: buy a channel with more outbound.',
    );
    expect(swapLiquidityShortfall(btcToUsdt as never, { channels: [] })).toMatch(/no channels/);
    expect(swapLiquidityShortfall(btcToUsdt as never, { channels: [usdtChannel({ ready: false })] })).toMatch(/none can send right now/);
  });

  it('BTC -> asset: an asset channel must be able to receive the asset', async () => {
    const { swapLiquidityShortfall } = await import('./kaleidoswap-atomic.js');
    expect(swapLiquidityShortfall(btcToUsdt as never, { channels: [usdtChannel({ asset_remote_amount: 5_000_000 })] })).toMatch(
      /^no channel can receive 30 USDT/,
    );
    expect(swapLiquidityShortfall(btcToUsdt as never, { channels: [usdtChannel({ inbound_balance_msat: 1_000_000 })] })).toMatch(
      /^no channel can receive 30 USDT/,
    );
  });

  it('asset -> BTC: the asset must be on our side and BTC inbound must cover amount + minimum', async () => {
    const { swapLiquidityShortfall } = await import('./kaleidoswap-atomic.js');
    expect(swapLiquidityShortfall(usdtToBtc as never, { channels: [usdtChannel()] })).toBeNull();
    expect(swapLiquidityShortfall(usdtToBtc as never, { channels: [usdtChannel({ asset_local_amount: 1_000_000 })] })).toMatch(
      /^no channel can send 10 USDT/,
    );
    expect(swapLiquidityShortfall(usdtToBtc as never, { channels: [usdtChannel({ inbound_balance_msat: 10_000_000 })] })).toBe(
      'your channels can receive at most 10,000 sats, and this swap pays you 18,000 sats (the amount plus the 3,000 sats HTLC minimum). Swap for less BTC, or get more inbound.',
    );
  });

  it("uses the node's HTLC minimum and doesn't block on unreadable data", async () => {
    const { swapLiquidityShortfall } = await import('./kaleidoswap-atomic.js');
    expect(swapLiquidityShortfall(btcToUsdt as never, { channels: [usdtChannel({ next_outbound_htlc_limit_msat: 51_000_000 })] }, 1_000_000)).toBeNull();
    expect(swapLiquidityShortfall(btcToUsdt as never, { channels: [{ channel_id: 'x' }] })).toBeNull();
    expect(swapLiquidityShortfall(btcToUsdt as never, 'not json')).toBeNull();
  });
});

describe('kaleidoswapAtomicRecipe — outbound preflight (BTC leg + RLN HTLC minimum)', () => {
  const btcQuote = {
    rfq_id: 'rfq-2',
    from_asset: { asset_id: 'BTC', ticker: 'BTC', layer: 'BTC_LN', amount_raw: 50_000_000, amount_display: '50,000 sats' },
    to_asset: { asset_id: 'rgb:usdt', ticker: 'USDT', layer: 'RGB_LN', amount_raw: 30_000_000, amount_display: '30' },
  };

  it('reports the shortfall in plain numbers', async () => {
    const { outboundShortfall } = await import('./kaleidoswap-atomic.js');
    expect(outboundShortfall(btcQuote as never, { channels: [{ ready: true, is_usable: true, outbound_balance_msat: 51_000_000 }] })).toBe(
      'your channels can send at most 51,000 sats, and this swap needs 53,000 sats (the amount plus the 3,000 sats HTLC minimum). Swap at most 48,000 sats, or buy a bigger channel.',
    );
    expect(outboundShortfall(btcQuote as never, { channels: [{ ready: true, next_outbound_htlc_limit_msat: 60_000_000 }] })).toBeNull();
    expect(outboundShortfall(btcQuote as never, { channels: [] })).toMatch(/no channels/);
    expect(outboundShortfall(btcQuote as never, { something: 'else' })).toBeNull();
    expect(outboundShortfall(btcQuote as never, { channels: [{ ready: false, outbound_balance_msat: 900_000_000 }] })).toMatch(/none can send right now/);
    expect(outboundShortfall(btcQuote as never, { channels: [{ channel_id: 'x' }] })).toBeNull();
    expect(outboundShortfall(btcQuote as never, undefined)).toBeNull();
  });

  it('stops before the confirmation and the init when no channel can carry the BTC leg', async () => {
    const calls: string[] = [];
    const confirms: unknown[] = [];
    const t = (name: string, response: unknown, spend = false) => ({
      name,
      description: name,
      parameters: { type: 'object', properties: {} },
      requiresConfirmation: spend,
      handler: async () => {
        calls.push(name);
        return response;
      },
    });
    const tools = new ToolRegistry([
      new InProcessToolSource('k', [
        t('kaleidoswap_get_quote', btcQuote),
        t('kaleidoswap_atomic_init', { swapstring: 's', payment_hash: 'p' }, true),
        t('kaleidoswap_atomic_execute', { status: 200 }, true),
      ]),
      new InProcessToolSource('rln', [
        t('rln_list_channels', { channels: [{ ready: true, is_usable: true, outbound_balance_msat: 3_000_000 }] }),
        t('rln_get_node_info', { pubkey: '03' }),
        t('rln_atomic_taker', { ok: true }, true),
      ]),
    ]);
    const res = await runRecipe(kaleidoswapAtomicRecipe, 'swap 50000 sats to usdt', {
      provider: { name: 'none', async runTurn() { throw new Error('unused'); } } as LLMProvider,
      tools,
      slots: { from_asset: 'BTC', to_asset: 'USDT', amount: 50000, amount_side: 'from' },
      recheckAfterMs: 0,
      onConfirm: async (c) => {
        confirms.push(c);
        return { approved: true };
      },
    });
    expect(res.status).toBe('error');
    expect(res.text).toMatch(/can send at most 3,000 sats.*needs 53,000 sats/);
    // The channel read is retried once (limits dip right after a payment).
    expect(calls).toEqual(['kaleidoswap_get_quote', 'rln_get_node_info', 'rln_list_channels', 'rln_list_channels']);
    expect(confirms).toEqual([]);
  });
});

describe('kaleidoswapAtomicRecipe — amounts and the deterministic path', () => {
  it('converts a BTC amount said in sats to display units for the quote', async () => {
    const { quoteAmount } = await import('./kaleidoswap-atomic.js');
    expect(quoteAmount('BTC', 2500, 'Swap 2500 sats into USDT')).toBe(0.000025);
    expect(quoteAmount('BTC', 0.001, 'swap 0.001 btc to usdt')).toBe(0.001);
    expect(quoteAmount('BTC', 100000, 'swap 100000 into usdt')).toBe(0.001);
    expect(quoteAmount('USDT', 10, 'swap 10 usdt for btc')).toBe(10);
  });

  it('runs "Swap 2500 sats into USDT" without a model, quoting 0.000025 BTC', async () => {
    const quoteArgs: unknown[] = [];
    const tools = new ToolRegistry([
      new InProcessToolSource('k', [
        {
          name: 'kaleidoswap_get_quote',
          description: 'q',
          parameters: { type: 'object', properties: {} },
          handler: async (a: Record<string, unknown>) => {
            quoteArgs.push(a);
            return { error: 'stop here' };
          },
        },
      ]),
    ]);
    const res = await runRecipe(kaleidoswapAtomicRecipe, 'Swap 2500 sats into USDT on KaleidoSwap', {
      provider: { name: 'none', async runTurn() { throw new Error('the model must not be called'); } } as LLMProvider,
      tools,
    });
    expect(res.inferences).toBe(0);
    expect(quoteArgs[0]).toMatchObject({ from_asset_id: 'BTC', to_asset_id: 'USDT', from_amount: 0.000025 });
  });
});

describe('kaleidoswapAtomicRecipe — follows the swap to a final status', () => {
  const quote = {
    rfq_id: 'rfq-7',
    from_asset: { asset_id: 'BTC', ticker: 'BTC', layer: 'BTC_LN', amount_raw: 2_500_000, amount_display: '0.000025' },
    to_asset: { asset_id: 'rgb:usdt', ticker: 'USDT', layer: 'RGB_LN', amount_raw: 2_020_173, amount_display: '2.020173' },
  };
  function setup(statuses: string[]) {
    const statusArgs: unknown[] = [];
    const confirms: string[] = [];
    const t = (name: string, handler: (a: any) => unknown, spend = false) => ({
      name, description: name, parameters: { type: 'object', properties: {} }, requiresConfirmation: spend, handler: async (a: any) => handler(a),
    });
    const tools = new ToolRegistry([
      new InProcessToolSource('k', [
        t('kaleidoswap_get_quote', () => quote),
        t('kaleidoswap_atomic_init', () => ({ swapstring: 's', payment_hash: 'ph-7', access_token: 'tok-7' }), true),
        t('kaleidoswap_atomic_execute', () => ({ status: 200 }), true),
        t('kaleidoswap_atomic_status', (a) => {
          statusArgs.push(a);
          return { swap: { status: statuses[Math.min(statusArgs.length - 1, statuses.length - 1)] } };
        }),
      ]),
      new InProcessToolSource('rln', [t('rln_get_node_info', () => ({ pubkey: '03' })), t('rln_atomic_taker', () => ({ ok: true }), true)]),
    ]);
    return { tools, statusArgs, confirms };
  }
  const run = (tools: ToolRegistry, confirms: string[], extra: Record<string, unknown> = {}) =>
    runRecipe(kaleidoswapAtomicRecipe, 'swap 2500 sats into usdt', {
      provider: { name: 'none', async runTurn() { throw new Error('unused'); } } as LLMProvider,
      tools,
      pollIntervalMs: 1,
      onConfirm: async (c) => { confirms.push(c.summary ?? ''); return { approved: true }; },
      ...extra,
    });

  it('polls with the access token until the swap succeeds, showing BTC in sats', async () => {
    const { tools, statusArgs, confirms } = setup(['Waiting', 'Pending', 'Succeeded']);
    const res = await run(tools, confirms);
    expect(statusArgs).toEqual([
      { payment_hash: 'ph-7', access_token: 'tok-7' },
      { payment_hash: 'ph-7', access_token: 'tok-7' },
      { payment_hash: 'ph-7', access_token: 'tok-7' },
    ]);
    expect(confirms[0]).toMatch(/^Swap 2,500 sats → 2\.020173 USDT/);
    expect(res.text).toBe('Swap completed: you sent 2,500 sats and received 2.020173 USDT.');
  });

  it('reports a failed swap, and how to check one that is not final yet', async () => {
    const failed = setup(['Pending', 'Expired']);
    expect((await run(failed.tools, failed.confirms)).text).toMatch(/^The swap expired: 2,500 sats → 2\.020173 USDT did not complete/);
    const pending = setup(['Pending']);
    const res = await run(pending.tools, pending.confirms, { pollTimeoutMs: 20 });
    expect(res.text).toMatch(/status Pending\. Check it with kaleidoswap_atomic_status\(payment_hash=ph-7, access_token=tok-7\)/);
  });
});

describe('swapLiquidityShortfall — a ticker instead of an rgb: id', () => {
  it("doesn't block on the asset leg it can't match", async () => {
    const { swapLiquidityShortfall } = await import('./kaleidoswap-atomic.js');
    const q = {
      from_asset: { asset_id: 'BTC', layer: 'BTC_LN', amount_raw: 2_500_000 },
      to_asset: { asset_id: 'USDT', ticker: 'USDT', layer: 'RGB_LN', amount_raw: 2_000_000 },
    };
    const ch = { ready: true, asset_id: 'rgb:usdt', asset_remote_amount: 1, next_outbound_htlc_limit_msat: 9_000_000, inbound_balance_msat: 9_000_000 };
    expect(swapLiquidityShortfall(q as never, { channels: [ch] })).toBeNull();
  });
});

describe('swapLiquidityShortfall — per-payment cap', () => {
  it('says when the balance is there but one payment is capped', async () => {
    const { swapLiquidityShortfall } = await import('./kaleidoswap-atomic.js');
    const q = { from_asset: { asset_id: 'BTC', layer: 'BTC_LN', amount_raw: 5_000_000 }, to_asset: { asset_id: 'USDT', layer: 'RGB_LN', amount_raw: 1 } };
    const ch = { ready: true, outbound_balance_msat: 20_000_000, next_outbound_htlc_limit_msat: 5_400_000 };
    expect(swapLiquidityShortfall(q as never, { channels: [ch] })).toBe(
      'one payment on your channels is capped at 5,400 sats right now (about 10% of channel capacity), and this swap sends 8,000 sats (the amount plus the 3,000 sats HTLC minimum). Swap at most 2,400 sats, or buy a channel of about 80,000 sats capacity.',
    );
  });
});

describe('kaleidoswapAtomicRecipe — a transient channel limit', () => {
  it('reads the channels again once and goes ahead when the limit is back', async () => {
    let reads = 0;
    const confirms: string[] = [];
    const t = (name: string, handler: () => unknown, spend = false) => ({
      name, description: name, parameters: { type: 'object', properties: {} }, requiresConfirmation: spend, handler: async () => handler(),
    });
    const quote = {
      rfq_id: 'r', from_asset: { asset_id: 'BTC', ticker: 'BTC', layer: 'BTC_LN', amount_raw: 2_500_000 },
      to_asset: { asset_id: 'rgb:usdt', ticker: 'USDT', layer: 'RGB_LN', amount_raw: 2_000_000, amount_display: '2' },
    };
    const tools = new ToolRegistry([
      new InProcessToolSource('k', [
        t('kaleidoswap_get_quote', () => quote),
        t('kaleidoswap_atomic_init', () => ({ swapstring: 's', payment_hash: 'p' }), true),
        t('kaleidoswap_atomic_execute', () => ({ status: 200 }), true),
      ]),
      new InProcessToolSource('rln', [
        t('rln_get_node_info', () => ({ pubkey: '03' })),
        t('rln_atomic_taker', () => ({ ok: true }), true),
        t('rln_list_channels', () => ({ channels: [{ ready: true, outbound_balance_msat: 40_000_000, next_outbound_htlc_limit_msat: ++reads === 1 ? 1_500_000 : 7_000_000 }] })),
      ]),
    ]);
    const res = await runRecipe(kaleidoswapAtomicRecipe, 'swap 2500 sats into usdt', {
      provider: { name: 'none', async runTurn() { throw new Error('unused'); } } as LLMProvider,
      tools,
      recheckAfterMs: 0,
      onConfirm: async (c) => { confirms.push(c.summary ?? ''); return { approved: false }; },
    });
    expect(reads).toBe(2);
    expect(confirms).toHaveLength(1);
    expect(res.status).toBe('cancelled');
  });
});

