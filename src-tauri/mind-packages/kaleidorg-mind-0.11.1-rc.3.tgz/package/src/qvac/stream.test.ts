import { describe, it, expect } from 'vitest';
import { consumeRun, type CompletionEventLike, type CompletionRunLike } from './stream.js';
import type { QvacFinalLike } from './parse.js';

function fakeRun(
  events: CompletionEventLike[],
  final: QvacFinalLike,
  requestId = 'req-1',
): CompletionRunLike {
  return {
    requestId,
    events: (async function* () {
      for (const e of events) yield e;
    })(),
    final: Promise.resolve(final),
  };
}

describe('consumeRun', () => {
  it('forwards visible content tokens and accumulates the streamed fallback', async () => {
    const tokens: string[] = [];
    const run = fakeRun(
      [
        { type: 'contentDelta', text: 'Hel' },
        { type: 'contentDelta', text: 'lo' },
      ],
      { contentText: '', toolCalls: [], raw: { fullText: '' } },
    );
    const out = await consumeRun(run, { onToken: (t) => tokens.push(t) });
    expect(tokens).toEqual(['Hel', 'lo']);
    // contentText empty ⇒ falls back to the streamed accumulation.
    expect(out.text).toBe('Hello');
  });

  it('routes thinkingDelta to onThinking, not onToken', async () => {
    const visible: string[] = [];
    const thinking: string[] = [];
    const run = fakeRun(
      [
        { type: 'thinkingDelta', text: 'plan…' },
        { type: 'contentDelta', text: 'Answer' },
      ],
      { contentText: 'Answer', toolCalls: [], raw: { fullText: 'Answer' } },
    );
    await consumeRun(run, {
      onToken: (t) => visible.push(t),
      onThinking: (t) => thinking.push(t),
    });
    expect(visible).toEqual(['Answer']);
    expect(thinking).toEqual(['plan…']);
  });

  it('returns parsed tool calls + requestId and flags truncation from stopReason', async () => {
    const run = fakeRun(
      [],
      {
        contentText: 'partial',
        toolCalls: [{ id: 't1', name: 'get_balance', arguments: {} }],
        raw: { fullText: 'partial' },
        stopReason: 'length',
      },
      'req-xyz',
    );
    const out = await consumeRun(run);
    expect(out.requestId).toBe('req-xyz');
    expect(out.toolCalls).toEqual([{ id: 't1', name: 'get_balance', arguments: {} }]);
    expect(out.truncated).toBe(true);
  });

  it('stops forwarding and flags when thinking exceeds maxThinkingTokens', async () => {
    const thinking: string[] = [];
    let exceeded = 0;
    // 8-char deltas ≈ 2 tokens each; budget 4 tokens trips after the 2nd.
    const run = fakeRun(
      [
        { type: 'thinkingDelta', text: 'aaaaaaaa' },
        { type: 'thinkingDelta', text: 'bbbbbbbb' },
        { type: 'thinkingDelta', text: 'cccccccc' },
        { type: 'contentDelta', text: 'should-not-arrive' },
      ],
      { contentText: '', toolCalls: [], raw: { fullText: '' }, stopReason: 'cancelled' },
    );
    const out = await consumeRun(run, {
      onThinking: (t) => thinking.push(t),
      maxThinkingTokens: 4,
      onThinkingBudgetExceeded: () => {
        exceeded += 1;
      },
    });
    expect(exceeded).toBe(1);
    expect(out.thinkingBudgetExceeded).toBe(true);
    expect(thinking).toEqual(['aaaaaaaa', 'bbbbbbbb']); // stopped at the trip
  });

  it('ignores delta events with no text', async () => {
    const tokens: string[] = [];
    const run = fakeRun(
      [{ type: 'contentDelta' }, { type: 'toolCall' }, { type: 'contentDelta', text: 'hi' }],
      { contentText: 'hi', toolCalls: [], raw: { fullText: 'hi' } },
    );
    await consumeRun(run, { onToken: (t) => tokens.push(t) });
    expect(tokens).toEqual(['hi']);
  });

  it('measures first-token and total completion timing', async () => {
    const ticks = [100, 145, 190];
    const out = await consumeRun(
      fakeRun([{ type: 'thinkingDelta', text: 'plan' }, { type: 'contentDelta', text: 'answer' }], {
        contentText: 'answer',
      }),
      { now: () => ticks.shift() ?? 190 },
    );
    expect(out.timing).toEqual({ ttftMs: 45, durationMs: 90 });
  });

  it('folds a rejected final (InferenceCancelledError) into a cancelled turn', async () => {
    class InferenceCancelledError extends Error {
      constructor(readonly requestId: string, readonly partial: { text?: string }) {
        super('cancelled');
      }
    }
    const run: CompletionRunLike = {
      requestId: 'req-c',
      events: (async function* () {
        yield { type: 'contentDelta', text: 'Partial' };
      })(),
      final: Promise.reject(new InferenceCancelledError('req-c', { text: 'Partial' })),
    };
    const out = await consumeRun(run);
    expect(out.stopReason).toBe('cancelled');
    expect(out.text).toBe('Partial');
    expect(out.toolCalls).toEqual([]);
  });

  it('re-throws a rejected final that is not a cancellation', async () => {
    const run: CompletionRunLike = {
      requestId: 'req-e',
      events: (async function* () {})(),
      final: Promise.reject(new Error('boom')),
    };
    await expect(consumeRun(run)).rejects.toThrow('boom');
  });
});


it('hides a budget closing marker even when split across content events', async () => {
  const tokens: string[] = [];
  const out = await consumeRun(fakeRun([
    { type: 'contentDelta', text: '</thi' },
    { type: 'contentDelta', text: 'nk>' },
    { type: 'contentDelta', text: 'OK' },
  ], { contentText: '</think>OK' }), { onToken: t => tokens.push(t) });
  expect(tokens.join('')).toBe('OK');
  expect(out.text).toBe('OK');
});
